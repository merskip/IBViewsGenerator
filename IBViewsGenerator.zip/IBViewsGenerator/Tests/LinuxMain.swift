import XCTest

import IBViewsGeneratorTests

var tests = [XCTestCaseEntry]()
tests += IBViewsGeneratorTests.allTests()
XCTMain(tests)