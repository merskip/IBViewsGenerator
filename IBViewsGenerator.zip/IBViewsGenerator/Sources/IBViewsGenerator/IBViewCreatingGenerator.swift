//
//  IBViewConstructGenerator.swift
//  IBViewsGenerator
//
//  Created by Piotr Merski on 16/04/2019.
//

import Foundation
import SWXMLHash

private typealias XMLElement = SWXMLHash.XMLElement

class IBViewCreatingGenerator {
    
    struct ViewCreating {
        let viewId: String
        let propertyName: String
        let className: String
        let methodName: String
        let methodBody: String
    }
    
    private let objectsStorage: IBObjectsStorage
    
    init(objectsStorage: IBObjectsStorage) {
        self.objectsStorage = objectsStorage
    }
    
    func generateViewCreating(view: XMLIndexer) throws -> ViewCreating {
        let viewElement = view.element!
        var method = ""
        
        let viewId = viewElement.getId()!
        
        let className = try viewElement.getClassName()
        let variableName = className.toSimpleVariableName()
        
        method += "let \(variableName) = \(className)()\n"
        switch view.getRect() {
        case .frame(let rect)?:
            method += "\(variableName).frame = \(creatingRect(rect: rect))\n"
        case .bounds(let rect)?:
            method += "\(variableName).bounds = \(creatingRect(rect: rect))\n"
        case .none: break
        }
        
        let boolProperty = { (propertyName: String) in
            method += self.configuringBoolProperty(variableName: variableName, viewElement: viewElement, propertyName: propertyName) ?? ""
        }
        let enumProperty = { (propertyName: String) in
            method += self.configuringEnumProperty(variableName: variableName, viewElement: viewElement, propertyName: propertyName) ?? ""
        }
        boolProperty("opaque")
        boolProperty("userInteractionEnabled")
        enumProperty("contentMode")
        enumProperty("textAlignment")
        enumProperty("lineBreakMode")
        enumProperty("baselineAdjustment")
        boolProperty("adjustsFontSizeToFit")
        boolProperty("translatesAutoresizingMaskIntoConstraints")
        
        if let text = viewElement.attribute(by: "text")?.text {
            method += "\(variableName).text = \"\(text)\"\n"
        }
        
        if let horizontalHuggingPriority = viewElement.getAttributeInt("horizontalHuggingPriority") {
            method += "\(variableName).setContentHuggingPriority(UILayoutPriority(rawValue: \(horizontalHuggingPriority)), for: .horizontal)\n"
        }
        
        if let verticalHuggingPriority = viewElement.getAttributeInt("verticalHuggingPriority") {
            method += "\(variableName).setContentHuggingPriority(UILayoutPriority(rawValue: \(verticalHuggingPriority)), for: .vertical)\n"
        }

        method += "return \(variableName)\n"
        
        let viewCreating =  ViewCreating(
            viewId: viewId,
            propertyName: objectsStorage.getSafePropertyName(for: variableName),
            className: className,
            methodName: "createView\(viewId.safeSymbol())",
            methodBody: method
        )
        objectsStorage.put(viewId: viewId, propertyName: viewCreating.propertyName)
        return viewCreating
    }
    
    private func configuringBoolProperty(variableName: String, viewElement: XMLElement, propertyName: String) -> String? {
        if let boolValue = viewElement.attribute(by: propertyName)?.text.toBool() {
            return "\(variableName).\(propertyName) = \(boolValue.toString())\n"
        }
        return nil
    }
    
    private func configuringEnumProperty(variableName: String, viewElement: XMLElement, propertyName: String) -> String? {
        if let enumValue = viewElement.attribute(by: propertyName)?.text {
            return "\(variableName).\(propertyName) = .\(enumValue)\n"
        }
        return nil
    }
    
    private func creatingRect(rect: CGRect) -> String {
        return "CGRect(x: \(rect.origin.x), y: \(rect.origin.y), width: \(rect.width), height: \(rect.height))"
    }
}

