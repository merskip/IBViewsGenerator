//
//  XMLIndexer.swift
//  IBViewsGenerator
//
//  Created by Piotr Merski on 16/04/2019.
//

import Foundation
import SWXMLHash


extension XMLIndexer {
    
    enum Rect {
        case frame(rect: CGRect)
        case bounds(rect: CGRect)
    }
    
    func getRect() -> Rect? {
        let rect = self["rect"]
        let rectElement = rect.element!
        
        let attrDouble = { (attrName: String) -> Double? in
            if let attrValue = rectElement.attribute(by: attrName)?.text {
                return Double(attrValue)
            }
            return nil
        }
        
        guard let x = attrDouble("x"),
            let y = attrDouble("y"),
            let width = attrDouble("width"),
            let height = attrDouble("height")
            else { return nil }
        
        let cgRect = CGRect(x: x, y: y, width: width, height: height)
        
        switch rectElement.attribute(by: "key")?.text {
        case "frame": return .frame(rect: cgRect)
        case "bounds": return .bounds(rect: cgRect)
        default: return nil
        }
    }
}
