//
//  IBParser.swift
//  IBViewsGenerator
//
//  Created by Piotr Merski on 16/04/2019.
//

import Foundation
import SWXMLHash

private typealias XMLElement = SWXMLHash.XMLElement

class IBParser {
    
    
    func parse(pathname: String) {
        let xmlData = FileManager.default.contents(atPath: pathname) ?? Data()
        let xml = SWXMLHash.parse(xmlData)
        let document = xml["document"]
        let objects = document["objects"]
        let views = objects["view"]
        
        views.all.forEach { (view) in
            let classExtension = try? generateView(view: view)
            print(classExtension ?? "error")
        }
    }
    
    private func generateView(view: XMLIndexer) throws -> String {
        let viewElement = view.element!
        var result = ""
        
        let className = try viewElement.getClassName()
        result += "extension \(className) {\n"
        result += "\n"
        
        let objectsStorage = IBObjectsStorage()
        let viewCreatingGenerator = IBViewCreatingGenerator(objectsStorage: objectsStorage)
        
        let xmlSubviews = view["subviews"]
        xmlSubviews.children.forEach { (subview) in
            
            if let viewCreating = try? viewCreatingGenerator.generateViewCreating(view: subview) {
                result += "\n"
                result += "   lazy var \(viewCreating.propertyName): \(viewCreating.className) = \(viewCreating.methodName)()\n"
                result += "\n"
                result += "   func \(viewCreating.methodName)() -> \(viewCreating.className) {\n"
                result += "      " + viewCreating.methodBody.trimmingCharacters(in: .newlines).replacingOccurrences(of: "\n", with: "\n      ") + "\n"
                result += "   }\n"
            }
        }
        
        result += "\n"
        result += "   func setupConstrains() {\n"
        result += "      "
        result += try IBViewConstraintsGenerator(objectsStorage: objectsStorage).generateConstraintsCreating(view: view)
            .trimmingCharacters(in: .newlines).replacingOccurrences(of: "\n", with: "\n      ") + "\n"
        result += "   }\n"
        
        result += "}\n"
        return result
    }
    
}
