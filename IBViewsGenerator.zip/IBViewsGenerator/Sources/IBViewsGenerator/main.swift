

IBParser().parse(pathname: "/Users/merskip/Workspace/IBViewsGenerator/Sources/IBViewsGenerator/ExampleView.xib")
