//
//  IBViewConstraintsGenerator.swift
//  IBViewsGenerator
//
//  Created by Piotr Merski on 16/04/2019.
//

import Foundation
import SWXMLHash

private typealias XMLElement = SWXMLHash.XMLElement

class IBViewConstraintsGenerator {
    
    private let objectsStorage: IBObjectsStorage
    
    init(objectsStorage: IBObjectsStorage) {
        self.objectsStorage = objectsStorage
    }
    
    func generateConstraintsCreating(view: XMLIndexer) throws -> String {
        
        let selfId = view.element!.getId()!
        objectsStorage.put(viewId: selfId, propertyName: "self")
        
        let constraints = view["constraints"].children
        var result = ""
        constraints.forEach { (constraint) in
            
            guard let constraintElement = constraint.element,
                let firstItemId = constraintElement.attribute(by: "firstItem")?.text ?? view.element?.getId(),
                let firstAttribute = constraintElement.attribute(by: "firstAttribute")?.text,
                let secondItemId = constraintElement.attribute(by: "secondItem")?.text,
                let secondAttribute = constraintElement.attribute(by: "secondAttribute")?.text
                else { return }
            
            
            let relation = constraintElement.attribute(by: "relation")?.text ?? "equal"
            let constant = constraintElement.attribute(by: "constant")?.text
            
            guard let firstItem = objectsStorage.getObject(viewId: firstItemId),
                let secondItem = objectsStorage.getObject(viewId: secondItemId)
                else { return }
            
            result += "\(firstItem.propertyName).\(firstAttribute)Anchor"
            result += ".constraint(\(relation)To: \(secondItem.propertyName).\(secondAttribute)Anchor"
            if let constant = constant {
                result += ", constant: \(constant)"
            }
            result += ").isActive = true\n"
        }
        
        return result
    }
}
