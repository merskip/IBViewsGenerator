//
//  IBObjectsStorage.swift
//  IBViewsGenerator
//
//  Created by Piotr Merski on 16/04/2019.
//

import Foundation


class IBObjectsStorage {
    
    struct Object {
        let viewId: String
        let propertyName: String
    }
    
    private var objects: [Object] = []
    
    func getSafePropertyName(for propertyName: String) -> String {
        if getObject(propertyName: propertyName) != nil {
            return getSafePropertyName(for: propertyName + "1")
        }
        else {
            return propertyName
        }
    }
    
    func put(viewId: String, propertyName: String) {
        objects.append(Object(viewId: viewId, propertyName: propertyName))
    }
    
    func getObject(viewId: String) -> Object? {
        return objects.first(where: { $0.viewId == viewId })
    }
    
    func getObject(propertyName: String) -> Object? {
        return objects.first(where: { $0.propertyName == propertyName })
    }
    
}
