//
//  XMLElement.swift
//  IBViewsGenerator
//
//  Created by Piotr Merski on 16/04/2019.
//

import Foundation
import SWXMLHash

extension SWXMLHash.XMLElement {
    
    enum Error: Swift.Error {
        case unknownClass(xmlElement: SWXMLHash.XMLElement)
    }
    
    func getId() -> String? {
        return attribute(by: "id")?.text
    }
    
    func getAttributeInt(_ attrName: String) -> Int? {
        if let attrValue = attribute(by: attrName)?.text {
            return Int(attrValue)
        }
        return nil
    }
    
    func getClassName() throws -> ClassName {
        guard let className = attribute(by: "customClass")?.text ?? getClassBasedOnTagName()
            else { throw Error.unknownClass(xmlElement: self) }
        return className
    }
    
    func getClassBasedOnTagName() -> ClassName? {
        switch name {
        case "view": return "UIView"
        case "label": return "UILabel"
        default: return nil
        }
    }
}
