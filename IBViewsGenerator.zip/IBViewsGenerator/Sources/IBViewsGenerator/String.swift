//
//  String.swift
//  IBViewsGenerator
//
//  Created by Piotr Merski on 16/04/2019.
//

import Foundation

typealias ClassName = String
typealias VariableName = String

extension ClassName {
    
    func toSimpleVariableName() -> VariableName {
        let prefixRegex = try! NSRegularExpression(pattern: "^[A-Z]*([A-Z])", options: [])
        if let firstMatch = prefixRegex.firstMatch(in: self, options: [], range: NSRange(location: 0, length: count)) {
            let classNameFirstLetter = self[Range(firstMatch.range(at: 1), in: self)!]
            
            let classNameNextPart = self[index(startIndex, offsetBy: firstMatch.range.upperBound)...]
            return classNameFirstLetter.lowercased() + classNameNextPart
        }
        else {
            return self
        }
    }
}

extension String {
    
    func capitalizingFirstLetter() -> String {
        return prefix(1).uppercased() + self.lowercased().dropFirst()
    }
    
    func safeSymbol() -> String {
        return replacingOccurrences(of: "-", with: "")
    }
    
    func toBool() -> Bool? {
        switch self {
        case "YES": return true
        case "NO": return false
        default: return nil
        }
    }
}

extension Bool {
    
    func toString() -> String {
        switch self {
        case true: return "true"
        case false: return "false"
        }
    }
}

